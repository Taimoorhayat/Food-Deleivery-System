function checkName() {
    let name = document.getElementById('name');
    let name_error = document.getElementById('name_error');

    const pattern = /^[A-Za-z ]*$/
    if (!pattern.test(name.value)) {
        name_error.innerHTML = "Invalid name";
    }else{
        name_error.innerHTML = "";
    }
}

function checkNumber() {
    let number = document.getElementById('number');
    let number_error = document.getElementById('number_error');

    const pattern = /^03([0-9]{2})-([0-9]{7})*$/
    if (!pattern.test(number.value)) {
        number_error.innerHTML = "Invalid phone number";
    }else{
        number_error.innerHTML = "";
    }
}